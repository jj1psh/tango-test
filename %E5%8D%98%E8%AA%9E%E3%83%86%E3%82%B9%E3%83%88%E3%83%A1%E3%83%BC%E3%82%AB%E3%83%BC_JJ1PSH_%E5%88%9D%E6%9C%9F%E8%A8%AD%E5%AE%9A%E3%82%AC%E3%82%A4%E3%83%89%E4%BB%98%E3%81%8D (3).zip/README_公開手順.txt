単語テストメーカー Webアプリ版（iPad用）

このフォルダには、ブラウザで開いてホーム画面に追加できるWebアプリ一式が入っています。

公開方法（GitHub Pages）
1. GitHubにサインインし、新しいリポジトリを作成します。
2. index.html / manifest.json / sw.js / icon-192.png / icon-512.png をリポジトリ直下にアップロードします。
3. Settings > PagesでDeploy from a branchを選び、Branchをmain、folderを/(root)にして保存します。
4. 公開URLを取得します。
5. Supabaseを含むログイン設定を、README_ログイン設定手順.txtのA・Bに沿って完了してから公開URLで動作確認してください。
6. iPadのSafariで公開URLを開き、共有 > ホーム画面に追加します。

ログインについて
- ログイン名はJJ1PSHです。パスワードはHTMLに保存せず、Supabase管理画面で設定します。
- 1つのSupabaseアカウントを2人で共有する方式です。
- SupabaseのProject URL、公開用キー、登録メールアドレスをindex.htmlに設定しないとログインできません。
- service_role / secret keyは絶対にHTMLへ書かないでください。

重要な制限
- GitHub Pagesは静的サイトです。ログイン画面は通常利用を制限するためのもので、HTMLや埋め込みTarget 1900データ自体を非公開にする機能ではありません。
- 単語データ・出題範囲は各端末のブラウザ内に保存され、他端末へ自動同期されません。
